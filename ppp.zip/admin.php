<?php
session_start();
include 'db.php';

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Agregar datos
if (isset($_POST['agregar'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $sql = "INSERT INTO datos (nombre, descripcion) VALUES ('$nombre', '$descripcion')";
    $conn->query($sql);
}

// Eliminar datos
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $sql = "DELETE FROM datos WHERE id=$id";
    $conn->query($sql);
}

// Editar datos
if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $sql = "UPDATE datos SET nombre='$nombre', descripcion='$descripcion' WHERE id=$id";
    $conn->query($sql);
}

// Obtener datos de la tabla
$datos = $conn->query("SELECT * FROM datos");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $_SESSION['usuario']; ?>!</h2>
    <a href="logout.php">Cerrar sesión</a>

    <h3>Agregar datos</h3>
    <form method="post" action="">
        <input type="text" name="nombre" placeholder="Nombre" required><br>
        <textarea name="descripcion" placeholder="Descripción" required></textarea><br>
        <button type="submit" name="agregar">Agregar</button>
    </form>

    <h3>Datos existentes</h3>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Acciones</th>
        </tr>
        <?php while ($row = $datos->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['nombre']; ?></td>
            <td><?php echo $row['descripcion']; ?></td>
            <td>
                <a href="?eliminar=<?php echo $row['id']; ?>">Eliminar</a>
                <form method="post" action="" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="text" name="nombre" value="<?php echo $row['nombre']; ?>">
                    <input type="text" name="descripcion" value="<?php echo $row['descripcion']; ?>">
                    <button type="submit" name="editar">Editar</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
