function actualizarReloj() {
    const reloj = document.getElementById('reloj');
    const now = new Date();
    const horas = String(now.getHours()).padStart(2, '0');
    const minutos = String(now.getMinutes()).padStart(2, '0');
    const segundos = String(now.getSeconds()).padStart(2, '0');
    reloj.textContent = `${horas}:${minutos}:${segundos}`;
  }
  
  // Actualiza el reloj cada segundo
  setInterval(actualizarReloj, 1000);
  
  // Llama a la función una vez al cargar la página
  actualizarReloj();